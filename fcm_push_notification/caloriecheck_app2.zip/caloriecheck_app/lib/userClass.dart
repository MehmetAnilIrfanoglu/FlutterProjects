class userClass{

  String email;
  String id;
  String name;
  String gender;
  String age;
  String weight;
  String height;
  String performance;


  userClass({this.id, this.name, this.gender, this.email, this.age,this.weight,this.height,this.performance});
}