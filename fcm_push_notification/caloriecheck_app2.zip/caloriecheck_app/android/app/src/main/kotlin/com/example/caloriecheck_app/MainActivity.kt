package com.example.caloriecheck_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
