Firebase 1 holds the data of the person such as name and gender
Firebase 1 updates from the drawer header in the first screen update section. It will push you to the login page and ask you to re-login if you make changes in persons features.
If person wants to delete its data and its hotmail from the server he/she can do it in the drawer header delete section

Database 1 holds the data of the food consumption
Calorie consumption in the Third Screen is determined by the database1
Database 2 holds same data as database1 but the changes in second screen doesn't effect database 2. So it works as a history.
Database 2 is given as a list in History section in drawer header.

Firebase 2 is history section in the Firestore, it only has insert function. It works like database 2 but there is no update or delete or query.
