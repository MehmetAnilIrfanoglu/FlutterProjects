import 'package:flutter/material.dart';
import 'FourthScreen.dart';
import 'login.dart';
import 'updateData.dart';
import 'history.dart';
import 'authentication.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

Future<void> _configureLocalTimeZone() async {
  tz.initializeTimeZones();
  var turkey = tz.getLocation('Europe/Istanbul');
  tz.setLocalLocation(turkey);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _configureLocalTimeZone();

  runApp(new MaterialApp(
    title: "Water notifications",
    debugShowCheckedModeBanner: false,
   
    home: FirstScreen(),
  ));
}

class FirstScreen extends StatefulWidget {
  @override
  _FirstScreenState createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  TextEditingController updateWeight = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Main Page',style: TextStyle(fontSize: 20)),
        backgroundColor: Colors.black,
      ),
      drawer: Drawer(

        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.black,
              ),
              child: Center(
                child: Text(
                  'Calorie Check',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                  ),
                ),
              ),
            ),


            ListTile(
              leading: Icon(Icons.history),
              title: Text('History'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => History()));
              },
            ),
            ListTile(
              leading: Icon(Icons.message),
              title: Text('Update Data'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => update()));
              },
            ),
            ListTile(
              leading: Icon(Icons.delete),
              title: Text('Delete Person'),
              onTap: () async{
                update()
                    .authService
                    .delete(
                    Login.newUser.id
                )
                    .then((value) {


                }).catchError((Error) {
                  print(Error);
                });
                update()
                    .authService
                    .deleteUser(

                )
                    .then((value) {

                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Login()));

                }).catchError((Error) {
                  print(Error);
                });
              },
            ),
          ],
        ),
      ),
      body: Container(
        height: (MediaQuery.of(context).size.height),
        width: (MediaQuery.of(context).size.width),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: (MediaQuery.of(context).size.width),
                height: (MediaQuery.of(context).size.height) / 2.2,
                decoration: BoxDecoration(
                  color: Colors.black,
                  border: Border.all(
                    color: Colors.white,
                    width: 3,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text('Calorie Check',style: TextStyle(fontSize: 50,color: Colors.white)),
                    Icon(
                      Icons.beach_access,
                      color: Colors.white,
                      size: 45.0,
                    ),
                  ],
                ),
              ),
            ),
            Expanded(child: ListView(
              children: [

                Container(
                  height: (MediaQuery.of(context).size.height) /19,

                  decoration: BoxDecoration(
                    color: Colors.black,
                    border: Border.all(
                      color: Colors.white,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Center(child: Text('Notifications', style: TextStyle(fontSize: 20,color: Colors.white))),
                ),
                Container(
                  width: (MediaQuery.of(context).size.width),
                  height: (MediaQuery.of(context).size.height) / 9,
                  child: FlatButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => FourthScreen()));
                    },
                    color: Colors.indigoAccent,
                    textColor: Colors.white,
                    disabledColor: Colors.grey,
                    disabledTextColor: Colors.black,
                    padding: EdgeInsets.all(7.0),
                    splashColor: Colors.blue,
                    child: Text(
                      'Did you know that a suitable diet would be beneficial for your life? '
                          'Click for more details.',
                      style: TextStyle(fontSize: 19.0),
                      softWrap: true,
                    ),
                  ),
                ),

              ],
            ),
            ),



          ],
        ),
      ),
    );
  }
}